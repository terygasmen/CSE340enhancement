<img src="/phpmotors/images/site/logo.png" alt='PHP Motors Logo' id='logo'>
<a href="" id="access">My Account</a>