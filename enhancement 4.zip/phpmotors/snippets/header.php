<img src="/phpmotors/images/site/logo.png" alt='PHP Motors Logo' id='logo'>
<a href="/phpmotors/accounts/?action=login">My Account</a>